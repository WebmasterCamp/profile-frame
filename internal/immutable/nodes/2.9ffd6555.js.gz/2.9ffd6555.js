import{P as m}from"../chunks/2.65344d44.js";export{m as component};
