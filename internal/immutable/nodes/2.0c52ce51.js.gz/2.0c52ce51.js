import{P as m}from"../chunks/2.e8a17e07.js";export{m as component};
