import{P as m}from"../chunks/2.8470a192.js";export{m as component};
