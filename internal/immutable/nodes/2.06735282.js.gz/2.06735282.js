import{P as m}from"../chunks/2.76c12c4e.js";export{m as component};
